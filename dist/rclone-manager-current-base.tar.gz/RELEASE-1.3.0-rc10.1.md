# Rclone Manager VPS 1.3.0-rc10.1 — Retirada do 4shared

- Remove a integração 4shared do painel e do importador de links.
- Mantém integralmente a nova tela Configurações em abas do RC10.
- Remove as rotas OAuth 4shared e o cliente `oauth_4shared.py`.
- Limpa Consumer Key/Secret, request/access tokens e metadados de conta 4shared previamente salvos no SQLite.
- A API da extensão passa a `drive-link-v12` e não anuncia mais suporte 4shared.
- Links 4shared novos são recusados com mensagem clara; jobs 4shared antigos não são executados.
- Extensão recomendada: Drive Link Copier 1.5.1, que não captura mais 4shared.

Motivo: nos testes reais o endpoint oficial `/v1_2/oauth/authorize` aceita o Request Token e abre o login, mas após autenticação não conclui a etapa de autorização/consentimento nem retorna ao callback de forma confiável. Sem um fluxo oficial funcional, o Manager não usa scraping, cookies de navegador, CAPTCHA automation ou JDownloader como fallback.
