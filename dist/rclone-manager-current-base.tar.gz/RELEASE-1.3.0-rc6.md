# VPS 1.3.0-rc6 — Gerenciador de Jobs Persistente

- Gerencia Scan + Execução (rename/move) no mesmo painel.
- Pausar, continuar e cancelar a execução no próximo checkpoint seguro.
- Seleção da execução e ordem persistidas no SQLite.
- Retoma execução após reinício do container/servidor (`apply_interrupted`).
- Operações de move usam manifesto pendente/aplicado para retomada idempotente.
- Progresso separado de scan e execução, com caminho atual e heartbeat.
- Cancelar preserva o que já foi aplicado; é possível continuar ou usar Undo.
- Undo concluído devolve os itens ao estado planejado.
- `Scans recentes` virou `Jobs / Operações recentes`.

Todos os recursos de Smart Classifier, NFO, pt-BR, Anime Multi-Source e FUSE self-heal permanecem incluídos.
