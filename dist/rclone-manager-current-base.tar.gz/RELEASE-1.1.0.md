# Rclone Manager VPS 1.1.0

## Google Advanced Engine + Storage Quota

- integração opcional com **eclone** e compatibilidade com **gclone** instalado;
- modo automático: eclone → gclone → Google Drive API `files.copy`;
- upload/gerenciamento de múltiplas Google Service Accounts;
- rotação SA, rolling SA, escolha aleatória, preload, anti-thrashing e parâmetros de paralelismo;
- eclone pode ser instalado pelo próprio painel em armazenamento persistente, sem `curl | bash`;
- cópia Google por ID/pasta pode usar o motor avançado server-side, mantendo fallback para a Drive API quando SA não está ativada;
- Dashboard e contas exibem armazenamento Google usado, livre e total via `about.storageQuota`;
- extensão recebe o espaço livre das contas e mostra no seletor de destino;
- Backup Completo Portátil v3 inclui Service Account JSONs quando configurados;
- fila/API anterior, OneDrive/SharePoint/MediaFire e fluxo download → upload → limpeza permanecem compatíveis.

### Service Accounts

Cada Service Account precisa ter permissão real na origem e na pasta de destino. Em My Drive, compartilhe a pasta utilizada pelo Manager com os e-mails das SAs. Em Shared Drives, adicione as SAs conforme a política do Drive.

As referências de 750 GB/copy-upload e 10 TB/download por conta são informações declaradas pelos projetos eclone/gclone e podem mudar no Google; o Manager não garante limites nem contorna permissões de acesso.
