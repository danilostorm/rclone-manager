# Rclone Manager VPS 1.3.0-rc7 — Media Renamer Safe Mode

RC7 abandona a categorização física automática e redesenha o Media Organizer como um renomeador assistido, inspirado no fluxo de FileBot e Rename My TV Series.

## Mudanças principais
- Smart Classifier removido do fluxo/UI. Nenhum gênero, tipo de áudio ou subcategoria move mídia automaticamente.
- Modo padrão **Renomear no local**: só troca o nome do arquivo dentro da pasta em que ele já está.
- Modo opcional **Estrutura Plex/Jellyfin** continua disponível, mas é uma escolha explícita do usuário.
- Formato de nome personalizável com tokens: `{title}`, `{original}`, `{year}`, `{season}`, `{season2}`, `{episode}`, `{episode2}`, `{episode3}`, `{s00e00}`, `{episode_title}`, `{ext}`.
- **Correspondência em lote**: escolha uma série/anime uma vez e aplique a todos os arquivos.
- Alinhamento por S/E detectado ou **Linear** (arquivo 1 = episódio inicial), útil para nomes ruins.
- Anime mantém AniDB / Anime-Lists; TMDb pode fornecer títulos localizados e títulos de episódios quando mapeado.
- Preview e Undo continuam obrigatórios no fluxo.
- Jobs antigos que contêm classificação automática pendente são marcados `legacy_review` e bloqueados para execução por segurança.

## Segurança
RC7 não executa plano antigo criado pelo classificador removido. Jobs concluídos continuam disponíveis para histórico/Undo. Para renomear de novo, faça um novo scan RC7.
