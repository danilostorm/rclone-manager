# Rclone Manager VPS 1.0.7

- Drive Link API v6.
- navegador de pastas da extensão agora cria pastas diretamente no Google Drive;
- permite excluir subpastas pelo navegador da extensão, sempre com confirmação explícita;
- a raiz do Drive nunca pode ser excluída;
- se uma pasta usada como destino for excluída, a extensão invalida a seleção e exige escolher outro destino;
- mantém fila persistente, iniciar agora, pausar, retomar, cancelar e download → upload → limpeza para fontes externas.
