#!/bin/bash
set -euo pipefail
APP_DIR="${APP_DIR:-/mnt/user/appdata/rclone-manager}"
MOUNT_ROOT="${MOUNT_ROOT:-/mnt/rclone-manager-remotes}"
cd "$APP_DIR"
VERSION="$(cat VERSION 2>/dev/null || echo 2.1.0-rc11-ha1)"
mkdir -p backups data cache
printf '[1/5] Preparando mounts...\n'
MOUNT_ROOT="$MOUNT_ROOT" ./scripts/prepare-mounts.sh
printf '[2/5] Criando backup e imagem de rollback...\n'
FROM_IMAGE=""
PREV_ID=""
if docker inspect rclone-manager >/dev/null 2>&1; then
  FROM_IMAGE="$(docker inspect -f '{{.Config.Image}}' rclone-manager 2>/dev/null || true)"
  PREV_ID="$(docker inspect -f '{{.Image}}' rclone-manager 2>/dev/null || true)"
  if [ -n "$PREV_ID" ]; then docker tag "$PREV_ID" local/rclone-manager-unraid:rollback; fi
fi
BACKUP_PATH="$(./backup.sh ./backups)"
printf '[3/5] Construindo v%s...\n' "$VERSION"
docker compose build --pull
printf '[4/5] Subindo serviços...\n'
docker compose up -d
printf '[5/5] Registrando atualização...\n'
python3 - "$FROM_IMAGE" "$BACKUP_PATH" "$VERSION" <<'PY'
import json, sys
from datetime import datetime, timezone
from pathlib import Path
from_image, backup, version = sys.argv[1:]
p = Path('data/update-meta.json')
p.write_text(json.dumps({
    'updated_at': datetime.now(timezone.utc).isoformat(),
    'from_image': from_image,
    'rollback_image': 'local/rclone-manager-unraid:rollback' if from_image else '',
    'backup': backup,
    'to_version': version,
}, indent=2, ensure_ascii=False), encoding='utf-8')
PY
chmod 600 data/update-meta.json || true
printf '\nRclone Manager Unraid v%s atualizado.\n' "$VERSION"
printf 'Backup: %s\n' "$BACKUP_PATH"
printf 'Logs: docker compose logs -f\n'
