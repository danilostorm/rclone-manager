# Rclone Manager VPS 1.3.0-rc4

## Smart Classifier

- Classificação física segura para Filmes, Séries e Anime.
- Filmes/Séries: categoria principal usando gêneros e keywords TMDb; regra especial de Luta/Artes Marciais.
- Anime: Dublados, Dual Audio, Legendados ou Sem PT-BR usando faixas reais via ffprobe quando possível, com fallback no nome/caminho.
- Anime: subpastas opcionais para Filmes, OVA/OAD e Especiais.
- Prévia mostra categoria e fonte da classificação antes de executar.
- O NFO recebe tags de classificação sem perder todos os gêneros originais.
- Scan continua dry-run; Undo permanece disponível.
