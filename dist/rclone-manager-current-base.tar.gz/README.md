# Rclone Manager VPS v1.1.0


## Media Organizer / Smart Renamer

Nova versão RC adiciona organização automática segura de bibliotecas para Plex/Jellyfin/Anime: scan somente leitura, prévia, score de confiança, revisão manual, TMDb + AniDB/Anime-Lists + AniList/Kitsu/MAL, títulos pt-BR, NFO, Smart Classifier para Filmes/Séries/Anime, rename server-side e Undo. Veja [`RELEASE-1.3.0-rc5.md`](RELEASE-1.3.0-rc5.md).

Edição para VPS Linux (Ubuntu/Debian), preparada para instalação em **`/opt/rclone-manager`**.

## Importação de links da extensão

A API v8 aceita Google Drive, OneDrive/SharePoint, MediaFire, Dropbox, Pixeldrain e arquivos HTTP/HTTPS diretos. Google Drive usa `files.copy` sem conteúdo local. Fontes externas são processadas **um arquivo por vez**: download no cache → upload resumível ao Google → confirmação → exclusão do temporário. A mesma reserva mínima de disco do importador OneDrive protege o servidor.

Base funcional: Rclone Manager Unraid 1.6.9, incluindo o fluxo validado de **OneDrive → Google Drive**, suporte a **Compartilhados comigo**, correção CSRF e fallback Microsoft Graph `/content` quando `@microsoft.graph.downloadUrl` não é fornecido.

## Instalação rápida na Oracle VPS

Requisitos: Ubuntu/Debian, acesso root/sudo e conexão com a internet. O instalador tenta instalar Docker, Docker Compose v2 e FUSE3 se estiverem ausentes.

```bash
unzip rclone-manager-vps-v1.1.0.zip
cd rclone-manager-vps-v1.1.0
chmod +x install.sh
sudo ./install.sh
```

O instalador copia a aplicação para:

```text
/opt/rclone-manager
```

Dados persistentes:

```text
/opt/rclone-manager/.env
/opt/rclone-manager/data
/opt/rclone-manager/cache
/opt/rclone-manager/backups
```

Mounts rclone no host:

```text
/mnt/rclone-manager-remotes
```

Porta Web padrão:

```text
8787/tcp
```

## Comandos úteis

```bash
sudo systemctl status rclone-manager
sudo systemctl restart rclone-manager
cd /opt/rclone-manager && sudo docker compose logs -f
cd /opt/rclone-manager && sudo ./backup.sh
cd /opt/rclone-manager && sudo ./update.sh
```

## Nginx Proxy Manager

Recomendado publicar o painel por HTTPS usando um domínio/subdomínio. O proxy deve encaminhar para o IP privado/host da VPS na porta `8787`.

Depois configure em **Configurações → URL base** algo como:

```text
https://rclone.seudominio.com
```

Essa URL é usada para formar os callbacks OAuth do Google e Microsoft.

## Segurança

- Não publique `.env`, banco SQLite, `rclone.conf`, tokens OAuth ou backups.
- Use senha forte e HTTPS.
- Se usar reverse proxy, não é necessário liberar a porta 8787 na Security List/NSG da Oracle para a Internet; mantenha-a acessível apenas conforme sua arquitetura.

## OneDrive compartilhado

A edição VPS mantém o fallback que já foi validado no Desktop: quando o Microsoft Graph não retorna `@microsoft.graph.downloadUrl`, o Manager consulta `/drives/{drive-id}/items/{item-id}/content`, segue o redirect temporário e faz o download local antes do upload resumível ao Google Drive.


## Backup completo portátil

A VPS 1.1.0 pode restaurar os backups completos criados no Unraid 1.7.0 e ZorinOS 1.3.0 em **Sistema → Restaurar / migrar configuração**. Depois de migrar para outro host, revise somente a URL pública OAuth no menu Configurações.


## Fila da Drive Link API (1.0.6)

A extensão pode iniciar uma tarefa com prioridade ou adicioná-la à fila FIFO. O painel **API / Extensão** permite pausar, retomar, cancelar, excluir e reorganizar tarefas aguardando.


## Gerenciamento de pastas pela extensão (1.0.8)
No seletor de destino da Drive Link API é possível criar pastas e mover subpastas para a lixeira. A exclusão exige confirmação explícita e a raiz do Drive é protegida.


### 1.0.8
- fila da extensão não é mais bloqueada por validação antecipada HTTP 404 de item Google Drive;
- validação real de acesso Google ocorre no worker e o erro fica gerenciável em API / Extensão;
- compatível com a extensão 1.2.2, que carrega as pastas automaticamente e remove o agrupamento redundante.

## Google Advanced Engine (1.1.0)

Em **Configurações → Google avançado** o Manager pode instalar e usar `eclone` como motor preferencial, detectar `gclone` já instalado e gerenciar múltiplos JSONs de Service Accounts. Com rotação SA ativa, cópias Google por ID/pasta usam o motor avançado server-side; sem isso, o fluxo continua na Google Drive API.

O Dashboard também consulta `Drive API about.storageQuota` e mostra usado, livre e total de cada conta. Service Accounts entram no Backup Completo Portátil v3 e devem ser tratadas como chaves privadas.

## Media Pool / Drive Union (1.2.0-rc1)
Em **Media Pool / Union**, selecione vários Drives e organize-os em categorias. Jellyfin/Plex pode apontar somente para `/mnt/rclone-manager-remotes/_media-pools/<pool>` em vez de administrar dezenas de mounts.

## RC8 Mobile First
A WebUI possui layout dedicado para celular: menu drawer, bottom navigation, tabelas em cards e formulários touch-friendly. O desktop permanece preservado.

## MultiServer / High Availability (1.4.0-rc11)

O menu **MultiServer / HA** adiciona um control plane para servidores interligados por Tailscale. Cada host executa um Agent independente; um host com função Gateway mantém os caminhos estáveis em `/media-union/*` para Plex/Jellyfin e acessa storages remotos por SFTP/rclone em modo somente leitura.

O RC11 inclui health check, probe real de storage, Primary/Secondary/Backup, failover/failback, prioridade, cooldown e histórico. Por segurança, failover automático só promove uma origem marcada `READY` com `100%` de cobertura e health OK. A replicação automática de arquivos será adicionada em uma etapa posterior com manifesto/verificação antes de qualquer sincronização destrutiva.
