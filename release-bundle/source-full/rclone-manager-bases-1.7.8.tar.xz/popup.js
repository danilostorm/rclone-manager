const info=document.getElementById('info'),open=document.getElementById('open');
(async()=>{try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id)throw new Error();chrome.tabs.sendMessage(tab.id,{type:'getLinks'},r=>{if(chrome.runtime.lastError||!r){info.textContent='Recarregue a página depois de instalar a extensão.';return}info.textContent=r.count?`${r.count} link${r.count>1?'s':''} compatível${r.count>1?'is':''} detectado${r.count>1?'s':''}.`:'Nenhum link compatível detectado nesta página.';open.disabled=!r.count;open.onclick=()=>chrome.tabs.sendMessage(tab.id,{type:'openPanel'},()=>window.close())})}catch(_){info.textContent='Não foi possível acessar a aba atual.'}})();
document.getElementById('options').onclick=()=>chrome.runtime.openOptionsPage();

document.getElementById('manager').onclick=()=>chrome.runtime.sendMessage({type:'openManager',path:'/api-manager'});
