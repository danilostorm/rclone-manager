# Rclone Manager - Drive Link Copier v1.1.1

Extensão Chrome/Chromium para detectar links de download em páginas e enviar o conteúdo para contas Google Drive cadastradas no Rclone Manager.

## Fontes suportadas

- Google Drive e Google Docs/Sheets/Slides/Forms;
- OneDrive e SharePoint, inclusive links públicos `/_layouts/15/download.aspx`;
- MediaFire público;
- Dropbox público;
- Pixeldrain público;
- links HTTP/HTTPS diretos com extensão de arquivo;
- links marcados pelo site com o atributo HTML `download`.

## Como a transferência funciona

- **Google Drive → Google Drive:** usa a API Google Drive `files.copy`; o conteúdo não passa pelo disco local.
- **Fontes externas → Google Drive:** o Rclone Manager baixa um arquivo por vez para o cache de importação, faz upload resumível, confirma o Google Drive e remove imediatamente o temporário antes de iniciar o próximo arquivo.
- A página e o navegador podem ser fechados depois que a tarefa foi criada no Manager.

Links que dependem de CAPTCHA, conta premium, DRM ou cookies da sessão do navegador não são contornados. O suporte é para links públicos acessíveis pelo servidor.

## Recursos

- botão `☁ Enviar` ao lado de cada link detectado;
- botão flutuante para importação em lote;
- seleção da conta Google e navegação nas pastas de destino;
- criação automática de pasta para agrupar episódios/arquivos;
- progresso do job executado no servidor;
- API Key específica, sem expor senha/cookies do painel.

## Instalação

1. Extraia o ZIP.
2. Abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e selecione a pasta da extensão.
5. No Rclone Manager, vá em **Configurações → Extensão de Links** e gere uma API Key.
6. Abra as opções da extensão e informe a URL do Manager e a API Key.

## Segurança

A extensão possui acesso às páginas para detectar links. Somente os links selecionados, seus rótulos e metadados básicos da página são enviados ao endereço do Rclone Manager configurado pelo usuário. A API Key fica no armazenamento local da extensão.

## v1.1.1

- compatível com Drive Link API v8;
- adiciona OneDrive/SharePoint, MediaFire, Dropbox, Pixeldrain e links diretos;
- mantém Google Drive com `files.copy` sem download local;
- fontes externas usam download → upload → confirmação → limpeza, um arquivo por vez.


## v1.1.1
- destino obrigatório antes de iniciar;
- pausa, retomada e cancelamento pelo painel da extensão;
- atalho para o gerenciador de tarefas da API no Rclone Manager.


## Fila 1.2.3

A extensão oferece **Iniciar agora** e **Adicionar à fila**. O Manager executa uma tarefa da API por vez; tarefas aguardando podem ser priorizadas e reorganizadas em **API / Extensão**.


## Navegador de pastas
- Criar e excluir pastas diretamente no seletor de destino da extensão.
- Exclusão exige confirmação e nunca permite excluir a raiz do Drive.
- Se a pasta excluída era o destino confirmado, a seleção é invalidada para evitar envio acidental.


## v1.2.3
- remove a opção redundante de criar pasta de agrupamento no envio;
- carrega automaticamente o navegador de pastas ao selecionar/trocar o Google Drive de destino;
- fila aceita links Google antes da validação de acesso do arquivo, que passa a ocorrer no worker e fica visível no gerenciador.


## Nova tentativa
Tarefas com erro ou aguardando correção podem ser reenviadas com **Tentar novamente** (prioridade) ou **Fim da fila**, sem recriar o link.
