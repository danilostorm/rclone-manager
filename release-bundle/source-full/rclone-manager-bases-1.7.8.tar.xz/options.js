const $ = id => document.getElementById(id);
function base(v){return (v||'').trim().replace(/\/+$/,'')}
async function load(){const d=await chrome.storage.local.get(['managerUrl','apiKey']);$('managerUrl').value=d.managerUrl||'';$('apiKey').value=d.apiKey||''}
async function test(){const u=base($('managerUrl').value),k=$('apiKey').value.trim();if(!u||!k)throw new Error('Preencha URL e API Key.');const r=await fetch(u+'/api/v1/extension/status',{headers:{Authorization:`Bearer ${k}`,Accept:'application/json'},cache:'no-store'});let d={};try{d=await r.json()}catch(_){}if(!r.ok||d.ok===false)throw new Error(d.error||`HTTP ${r.status}`);return d}
async function run(save){$('status').textContent='Testando...';$('status').className='';try{if(save)await chrome.storage.local.set({managerUrl:base($('managerUrl').value),apiKey:$('apiKey').value.trim()});const d=await test();$('status').textContent=`Conectado ✓ Rclone Manager ${d.version||''}`;$('status').className='ok'}catch(e){$('status').textContent=e.message;$('status').className='err'}}
$('save').onclick=()=>run(true);$('test').onclick=()=>run(false);load();
