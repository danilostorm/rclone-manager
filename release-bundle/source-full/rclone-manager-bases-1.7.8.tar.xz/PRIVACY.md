# Privacidade

A extensão roda localmente no navegador e detecta links compatíveis nas páginas visitadas: Google Drive, OneDrive/SharePoint, MediaFire, Dropbox, Pixeldrain e arquivos HTTP/HTTPS diretos.

Nenhum conteúdo da página é enviado automaticamente a serviços de terceiros pela extensão. Quando o usuário inicia uma importação, somente os links selecionados, seus rótulos, o título e a URL da página são enviados exclusivamente ao endereço do Rclone Manager configurado pelo usuário.

A extensão não envia cookies da página, senhas ou sessões de login para o Rclone Manager. Por isso, links que só funcionam com uma sessão autenticada no navegador podem não ser importáveis pelo servidor.
